def say_hello():
    print("Hello World !")